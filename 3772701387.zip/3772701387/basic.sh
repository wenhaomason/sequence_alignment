#!/bin/bash
g++ basic.cpp -o basic
./basic "$1" "$2" 