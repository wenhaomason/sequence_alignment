#!/bin/bash
g++ efficient.cpp -o efficient
./basic "$1" "$2" 